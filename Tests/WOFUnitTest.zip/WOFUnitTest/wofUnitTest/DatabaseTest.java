package wofUnitTest;
import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DatabaseTest {

    private Database database;
    private Random random;

    @Before
    public void setUp() throws Exception {
        database = new Database();
        random = new Random();
    }

    @After
    public void tearDown() throws Exception {
        database = null;
        random = null;
    }

    @Test
    public void testGetRandomCategory() {
        String category = database.getRandomCategory();
        assertNotNull(category);
        assertTrue(category.length() > 0);
    }

    @Test
    public void testGetRandomWord() {
        String category = database.getRandomCategory();
        String word = database.getRandomWord(category);
        assertNotNull(word);
        assertTrue(word.length() > 0);
    }

    @Test
    public void testQuery() {
        // Assuming there is a 'User' table in your database
        String query = "SELECT * FROM User";
        ArrayList<String> result = database.query(query);
        assertNotNull(result);
        assertTrue(result.size() > 0);
    }

    @Test
    public void testAccountExists() throws SQLException {
        
        String username = "testuser" + random.nextInt(1000); 
        String password = "testpassword" + random.nextInt(1000); 
        boolean exists = database.accountExists(username, password);
        assertFalse(exists); 
    }

    @Test
    public void testVerifyAccount() throws SQLException {
        
        String username = "testuser" + random.nextInt(1000); 
        String password = "testpassword" + random.nextInt(1000); 
        boolean verified = database.verifyAccount(username, password);
        assertFalse(verified); 
}
}
